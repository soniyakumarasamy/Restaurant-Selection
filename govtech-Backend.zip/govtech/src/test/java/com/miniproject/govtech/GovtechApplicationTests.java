package com.miniproject.govtech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GovtechApplicationTests {

	@Test
	void contextLoads() {
	}

}
